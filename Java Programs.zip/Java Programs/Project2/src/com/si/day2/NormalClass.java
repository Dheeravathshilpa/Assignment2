package com.si.day2;

public class NormalClass {
	int a=10;
	static int b=20;
	String display(){
	 return "hello Display";
	}
	static String display1() {
		return "Hello static display";
	}
	 
	
		
	

}
