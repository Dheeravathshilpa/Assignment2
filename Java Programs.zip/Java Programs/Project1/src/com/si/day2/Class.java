package com.si.day2;

public class Class {
	int a=10;
	static int b=20;
public static void main(String[] args) {
	int c=30;
	Class obj=new Class();
	System.out.println(obj.a);
	System.out.println(Class.b);
	System.out.println(b);
	System.out.println(c);
	
	
}

}
